<script>
	export default {
		// 此处globalData为了演示其作用，不是uView框架的一部分
		globalData: {
			username: '白居易'
		},
		onLaunch() {
			// 1.1.0版本之前关于http拦截器代码，已平滑移动到/common/http.interceptor.js中
			// 注意，需要在/main.js中实例化Vue之后引入如下(详见文档说明)：
			// import httpInterceptor from '@/common/http.interceptor.js'
			// Vue.use(httpInterceptor, app)
		},
	}
</script>

<style lang="scss">
	@import "uview-ui/index.scss";
	@import "common/demo.scss";
	@import  "common/css/iconfont.css";
	$color:#5466ff;
	/*每个页面公共css */
	.Limit{
		width: 709rpx;
		height: 100%;
		margin: 0 auto;
	}
	.flexCenter{
		display: flex;
		justify-content: center;
		align-items: center;
	}
	.hover-class{
	    position: relative;
	    top: 3rpx;
	    left: 3rpx;
	    box-shadow: 0px 0px 8px rgba(0,0,0,.1) inset;
	}
	.small-hover{
	    opacity: 0.9;
	    transform: scale(0.95,0.95);
	}
	.medium-hover{
	    opacity: 0.8;
	    transform: scale(0.85,0.85);
	}
</style>